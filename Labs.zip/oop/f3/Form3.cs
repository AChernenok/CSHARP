﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp11
{
    public partial class Form3 : WindowsFormsApp11.Form1
    {
        public Form3()
        {
            InitializeComponent();
        }
    }
}
